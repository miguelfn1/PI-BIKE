function fMasc(objeto,mascara) {
	obj=objeto;
	masc=mascara;
	setTimeout("fMascEx()",1);
}
function fMascEx() {
	obj.value=masc(obj.value);
}
function mHora(hora){
	hora=hora.replace(/\D/g,"");
	hora=hora.replace(/(\d)(\d{2})$/,"$1:$2");
	return hora;
}
function mData(data){
	data=data.replace(/\D/g,"");
	data=data.replace(/(\d)(\d{4})$/,"$1/$2");
	data=data.replace(/(\d)(\d{2})$/,"$1/$2");
	return data;
}
function mTel(tel) {
	tel=tel.replace(/\D/g,"");
	tel=tel.replace(/^(\d{2})(\d)/g,"($1) $2");
	tel=tel.replace(/(\d)(\d{4})$/,"$1-$2");
	return tel;
}
function mCNPJ(cnpj){
	cnpj=cnpj.replace(/\D/g,"");
	cnpj=cnpj.replace(/^(\d{2})(\d)/,"$1.$2");
	cnpj=cnpj.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3");
	cnpj=cnpj.replace(/\.(\d{3})(\d)/,".$1/$2");
	cnpj=cnpj.replace(/(\d{4})(\d)/,"$1-$2");
	return cnpj;
}
function mCPF(cpf){
	cpf=cpf.replace(/\D/g,"");
	cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2");
	cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2");
	cpf=cpf.replace(/(\d{3})(\d{1,2})$/,"$1-$2");
	return cpf;
}
function mRG(rg){
	rg=rg.replace(/\D/g,"");
	rg=rg.replace(/(\d)(\d{7})$/,"$1.$2");
	rg=rg.replace(/(\d)(\d{4})$/,"$1.$2");
	rg=rg.replace(/(\d)(\d)$/,"$1-$2");
	return rg;
}
function mCEP(cep){
	cep=cep.replace(/\D/g,"");
	cep=cep.replace(/^(\d{5})(\d)/,"$1-$2");
	return cep;
}
function mNum(num){
	num=num.replace(/\D/g,"");
	return num;
}
function mValor(valor){
	valor=valor.replace(/\D/g,"");
	valor=valor.replace(/(\d)(\d{5})$/,"$1.$2");
	valor=valor.replace(/(\d)(\d{2})$/,"$1,$2");
	return valor;
}
function mInch(inch){
	inch=inch.replace(/\D/g,"");
	inch=inch.replace(/^(\d{1})(\d)/,"$1.$2");
	return inch;
}
function mVers(vers){
	vers=vers.replace(/\D/g,"");
	vers=vers.replace(/(\d)(\d{2})$/,"$1.$2");
	vers=vers.replace(/(\d)(\d{1})$/,"$1.$2");
	return vers;
}
function mRels(rels){
	rels=rels.replace(/\D/g,"");
	rels=rels.replace(/(\d)(\d{4})$/,"$1 x $2");
	return rels;
}
function mBate(bate){
	bate=bate.replace(/\D/g,"");
	bate=bate.replace(/(\d)(\d{3})$/,"$1.$2");
	return bate;
}
function mDim(dim){
	dim=dim.replace(/\D/g,"");
	dim=dim.replace(/(\d)(\d{6})$/,"$1.$2");
	dim=dim.replace(/(\d)(\d{5})$/,"$1 x $2");
	dim=dim.replace(/(\d)(\d{3})$/,"$1.$2");
	dim=dim.replace(/(\d)(\d{2})$/,"$1 x $2");
	dim=dim.replace(/(\d)(\d{1})$/,"$1.$2");
	return dim;
}
function mCard(card){
	card=card.replace(/\D/g,"");
	card=card.replace(/^(\d{4})(\d)/g,"$1 $2");
	card=card.replace(/^(\d{4})\s(\d{4})(\d)/g,"$1 $2 $3");
	card=card.replace(/^(\d{4})\s(\d{4})\s(\d{4})(\d)/g,"$1 $2 $3 $4");
	return card;
}

// by Pedro Américo