<?php session_start(); ?>
<!DOCTYPE html>

<html>
<head>
    <?php include'head.php'?>
	<title></title>
    <link rel="shortcurt icon" href="../IMGs/Icon_top.png">
    
    <style>
  body {
    margin: 0px;
    padding: 0px;
    background: url(../IMGs/road2.png)no-repeat;
    webkit-background-size:cover;
    background-size: cover;
    font-family:Acme,sans-serif;


}
    	.form-area2{
        position: absolute;
        top:20%;
        left:40%;
        transform: translate(-50%, -50%);
        widows:400px;
        height:250px;
        box-sizing: border-box;
        background: rgba(0,0,0,0);
        padding:40px;
    }
   
    .form-area2 p{
    	margin: 0px;
    	padding: 0px;
    	font-weight: bold;
    	color: #00bfff;

    }

.form-area2 input[type=submit]{
    border: none;
    height: 40px;
    width: 17%;
    outline: none;
    color: #ffffff;
    font-size: 15px;
    background-color: #00bfff;
    cursor: pointer;
    border-radius: 10px;
    margin-left: 40%;


}
@media(max-width: 1050px) {
    body {
        background: none;
    }
    </style>
</head>
<body>

    <h2 style="text-align: center; color: #00bfff">Destalhes da Manutenção</h2>
	<?php 

	echo "<div class='form-area2'>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Ordem de serviço:</p>
                <label></label>
             
        </div>
<form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Código da bike:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Marca:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Tamanho do Quadro:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Modelo:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Aro:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Tipo:</p>
                <label></label>
             
        </div>
<form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Cor:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>Genero:</p>
                <label></label>
             
        </div>
        <form action='#' method='post' class='form-group row'>


<div class='col-lg-6 col-md-12 col-sm-12'>
                <p>descrição de Manutenção:</p>
                <label></label>
             
        </div>


        </div>";




	//echo " Agendamento Realizado em:" $;	


	//echo "<button>Detalhes</button>";

	 ?>


</body>
</html>