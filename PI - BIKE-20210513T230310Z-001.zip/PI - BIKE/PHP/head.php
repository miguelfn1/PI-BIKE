<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/style.css">


	    <?php 
	            $servername = "localhost";
	            $username = "root";
	            $password = "";
	            $dbname = "infinitybike";
	            $conn = new mysqli($servername, $username, $password, $dbname);
	            mysqli_set_charset($conn, 'utf8');

	            if ($conn->connect_error) {
	                die("Connection failed: " . $conn->connect_error);
	            }

	            
	        	if (!isset($_SESSION["logado"])) {
	            	$_SESSION["logado"] = "";
	        	}
	     ?>