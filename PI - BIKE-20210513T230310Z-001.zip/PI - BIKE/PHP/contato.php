<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <title>PROJETO BICICLETARIA</title>
    <link rel="stylesheet" href="">
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcurt icon" href="icon.png">

</head>

<body style="background-image: url(road3.png);">
    <div class="container">
        <header>
            <input type="checkbox" id="btn-menu">
            <label for="btn-menu">&#9776;</label>
            <nav class="menu">
                <p id="logo_marca">PROJETO BICICLETARIA</p>
                <ul>
                    <li><a href="index.html">INICIO</a></li>
                    <li><a href="servicos.php">SERVIÇOS</a></li>
                    <li><a href="sobre.php">SOBRE NÓS</a></li>
                    <li><a href="contato.php">CONTATO</a></li>
                    <li><a href="#">LOGIN</a></li>
                </ul>
            </nav>
        </header>
    </div>
    <br><br>
    <footer>
    <div class="row">
            <div class="col-sm-4">
                <div class="contato-1"> <br>
                    <h3><span id="icon-color" class="glyphicon glyphicon-map-marker"></span>&nbsp;Endereço</h3>
                    Logradouro: Rua São José, Nº 19 <br>
                    Bairro: Condomínio Jequirituba <br>
                    Cidade: São Paulo-SP <br>
                    CEP: 04851-602
                </div>
            </div>
            <div class="col-sm-4">
                <div class="contato-1"> <br>
                    <h3><span id="icon-color" class="glyphicon glyphicon-earphone"></span>&nbsp;Telefones</h3>
                    Fixo: 11 - 59322000 <br>
                    Celular: 11 - 989875220 <br>
                    Whatsapp: 11 - 937878999

                </div>
            </div>
            <div class="col-sm-4">
                <div class="contato-1"> <br>
                    <h3><span id="icon-color" class="glyphicon glyphicon-thumbs-up"></span>&nbsp;Redes Sociais</h3>
                    <br><br>
                    <a href="#"><img src="IMG_DADOS/face_icon.png" alt=""></a>
                    <a href="#"><img src="IMG_DADOS/twitter_icon.png" alt=""></a>
                    <a href="#"><img src="IMG_DADOS/instagram_icon.png" alt=""></a>

                </div>
            </div>
        </div>
    </footer>
</body>
</html>
