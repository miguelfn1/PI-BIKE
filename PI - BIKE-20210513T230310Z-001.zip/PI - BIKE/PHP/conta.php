<?php session_start(); ?>
<!DOCTYPE html>
<html lang="">
<?php include'head.php'?>
<head>
    <title>Infinity Bikes - Conta</title>
    <link rel="shortcurt icon" href="../IMGs/icon.png">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family:Acme,sans-serif;
            font-size: 18px;
        }
        .contact-form{
            width: 85%;
            max-width: 600px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 30px 40px;
            box-sizing: border-box;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 0 20px #000000b3;
        }
        .contact-form h1{
            margin-top: 0;
            font-weight: 200; 
        }
        .txtb{
            border-radius: 1px solid gray;  
            margin: 8px 0;
            padding: 12px 18px;
            border-radius: 8px;
        }
        .txtb label{
            display: block;
            text-align: left;
            color: #333;
            text-transform: uppercase;
            font-size: 15px;   
        }
        .txtb input{
            width: 100%;
            border: none;
            background: none;
            outline: none;
            font-size: 18px;
            margin-top: 6px;
        }
        .btn{
            display: block;
            background: #00bbf5;
            padding: 14px 0;
            color: white;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 8px;
            width: 100%;
        }
        </style>
    </head>
    <body style="background-image: url(../IMGs/road2.png);">
        <?php
            echo "<div class='container'>
            <header>
                <input type='checkbox' id='btn-menu'>
                <label for='btn-menu'>&#9776;</label>
                <nav class='menu'>
                    <p id='logo_marca'><img src='../IMGs/logo-1.png' width='15%' alt=''>&nbsp;INFINITY BIKES</p>
                    <ul>
                        <li><a href='../PHP/home.php'>INICIO</a></li>
                        <li><a href='../PHP/servicos.php'>SERVIÇOS</a></li>
                        <li><a href='../PHP/sobre.php'>SOBRE NÓS</a></li>";
                        if ($_SESSION["logado"] != "") {
                                echo "<li><a href='../PHP/conta.php'>CONTA</a></li>
                                <li><a href='?lt'>SAIR</a></li>  ";
                            if (isset($_GET["lt"])) {
                               session_destroy();
                                echo "<script>location.href='../PHP/home.php';</script>";
                            }
                        }else{
                                echo "<li><a href='../PHP/login.php'>LOGIN</a></li>";
                        }
                     echo "
                    </ul>
                </nav>
            </header>
        </div>";
    ?>


<?php 

    

?>     

<div class="contact-form">
    <h1>Olá &nbsp; <?php echo "$_SESSION[logado]"; ?> !</h1>
    <div class="txtb">
        <label style="text-align: center;font-size: 22px;">Manutenções:</label>
    </div>
    <?php 

        $sql = "SELECT * FROM ordem_servico WHERE COD_CLI = ".$_SESSION['codigo'];
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $status=$row['STATUS_SER'];
            $valor=$row['VALOR_OBRA'];
            }

        if ($result->num_rows > 0) {
            echo "<label>Status da Manutenção:</label>&nbsp;";
            echo "$status";
            echo "<br>";
            echo "<label>Valor da Manutenção:</label>&nbsp;";
            echo "$valor";
            
        }else{
            echo "<label>Nenhuma Manutenção agendada.</label>";
            echo "<br>";
            echo "<a href='../PHP/servicos.php'>Realizar Manutenção?</a>";
        }
    ?>
</div>

</body>
</html>