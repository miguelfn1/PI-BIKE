<?php session_start(); ?>
<!DOCTYPE html>
<html lang="">
<?php include '../PHP/head.php' ?>
<head>
    <title>Infinity Bikes - História</title>
    <link rel="shortcurt icon" href="../IMGs/icon.png">
    <style>
        .content {
    text-align: justify;
    text-indent: 25px;
    margin-left: 10px;
    margin-right: 10px;
}

.content h1 {
    border-bottom: 3px solid #00bfff;
    color: #00BFFF  ;
}

.content p {
    color: #000;
    font-size: 20px;
}
body{
        font-family:Acme,sans-serif;
        font-size: 18px;
        background-repeat: no-repeat;
        background-image: url(../IMGs/road2.png);
    }
    @media(max-width: 1050px) {
    body {
        background: none;
    }


    </style>
</head>

<body style="">
    <?php
            echo "<div class='container'>
            <header>
                <input type='checkbox' id='btn-menu'>
                <label for='btn-menu'>&#9776;</label>
                <nav class='menu'>
                    <p id='logo_marca'><img src='../IMGs/logo-1.png' width='15%' alt=''>&nbsp;INFINITY BIKES</p>
                    <ul>
                        <li><a href='../PHP/home.php'>INICIO</a></li>
                        <li><a href='../PHP/servicos.php'>SERVIÇOS</a></li>
                        <li><a href='../PHP/sobre.php'>SOBRE NÓS</a></li>";
                        if ($_SESSION["logado"] != "") {
                                echo "<li><a href='../PHP/conta.php'>CONTA</a></li>
                                <li><a href='?lt'>SAIR</a></li>  ";
                            if (isset($_GET["lt"])) {
                               session_destroy();
                                echo "<script>location.href='../PHP/home.php';</script>";
                            }
                        }else{
                                echo "<li><a href='../PHP/login.php'>LOGIN</a></li>";
                        }
                     echo "
                    </ul>
                </nav>
            </header>
        </div>";
    ?>
     <div class="content">
            <h1>Nossa História</h1>
            <br>
            <p>
             Em 1855, o ferreiro francês especialista em carruagens, Pierre Michaux, inventou o pedal. Este foi instalado num veículo de duas rodas traseiras e uma dianteira. Chamado de velocípede, é considerado a primeira bicicleta moderna.</p>

<p>
            A primeira bicicleta a possuir um sistema com corrente ligada às rodas foi projetada por H.J.Lawson, no ano de 1874. Seu terceiro modelo, a “Bicyclette”, foi desenhado em 1879. Esta bicicleta já possuía maior estabilidade e segurança. 
</p>
<p>
            Na década de 1880, o inventor inglês John Kemp Starley projetou uma bicicleta semelhante as atuais. Possuía guidão, rodas de borracha, quadro, pedais e correntes.
            </p>
            <p>
                 Nós da Infinity Bikes viemos para o mercado para trazer a facilidade e praticidade dos nossos clientes com a agendamento on-line.
            </p>
            <p>
                Agende sua manutenção e traga sua bicicleta e acompanhe o processso pelo nosso site ou pelo nosso aplicativo.
            </p>
            
        </div>
    <footer>
            <p class="text-center">&copy; Todos direitos reservados.</p>
    </footer>
</body>

</html>
