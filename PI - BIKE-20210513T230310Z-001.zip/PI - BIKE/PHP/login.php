<?php session_start(); ?>
<!DOCTYPE html>
<html lang="">
<?php include'head.php'?>
<head>
    <title>Infinity Bikes - Login</title>
    <link rel="shortcurt icon" href="../IMGs/icon.png">
    <style>
        body {
            font-family:Acme,sans-serif;
            font-size: 18px;
        }
        .form-area{
            position: absolute;
            top:40%;
            left:50%;
            transform: translate(-50%, -50%);
            widows:400px;
            height:400px;
            box-sizing: border-box;
            background: rgba(0,0,0,0);
            padding:40px;
        }
        h2{
            margin:0px;
            padding: 0 0 20px;
            font-weight: bold;
            color: #ffffff;
            text-align: center;
        }
        .form-area p{
            margin: 0px;
            padding: 0px;
            font-weight: bold;
            color: #00bfff;

        }
        .form-area input,select{
            margin-bottom: 20px;
            width: 100%;
        }
        .form-area input[type=text],
        .form-area input[type=email]
        {
            border:none;
            border-bottom: 1px solid #000000;
            background-color:transparent;
            outline:none;
            height:40px;
            color:#0000000;
            display:16px;


        }
        .form-area input[type=password],
        .form-area input[ type=password]
        {
            border: none;
            border-bottom: 1px solid #000000;
            background-color: transparent;
            outline:none;
            height: 40px;
            color: #00bfff;
            display: 16px;


        }
        ::placeholder{
            color: #000000;
        }
        .form-area select 
        {
            margin-top:20px;
            padding:10px 0;
        }
        .form-area input[type=submit]{
            border: none;
            height: 40px;
            outline: none;
            color: #ffffff;
            font-size: 15px;
            background-color: #00bfff;
            cursor: pointer;
            border-radius: 10px;
            font-weight: bold;

        }

        .form-area a {
            color: #00bfff;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
        }
        @media(max-width: 1050px) {
            body {
                background: none;
            }
        </style>
    </head>
    <body style="background-image: url(../IMGs/road2.png);">
        <?php
            echo "<div class='container'>
            <header>
                <input type='checkbox' id='btn-menu'>
                <label for='btn-menu'>&#9776;</label>
                <nav class='menu'>
                    <p id='logo_marca'><img src='../IMGs/logo-1.png' width='15%' alt=''>&nbsp;INFINITY BIKES</p>
                    <ul>
                        <li><a href='../PHP/home.php'>INICIO</a></li>
                        <li><a href='../PHP/servicos.php'>SERVIÇOS</a></li>
                        <li><a href='../PHP/sobre.php'>SOBRE NÓS</a></li>";
                        if ($_SESSION["logado"] != "") {
                                echo "<li><a href='../PHP/conta.php'>CONTA</a></li>
                                <li><a href='?lt'>SAIR</a></li>  ";
                            if (isset($_GET["lt"])) {
                               session_destroy();
                                echo "<script>location.href='../PHP/home.php';</script>";
                            }
                        }else{
                                echo "<li><a href='../PHP/login.php'>LOGIN</a></li>";
                        }
                     echo "
                    </ul>
                </nav>
            </header>
        </div>";
    ?>
        

         <div class="form-area">
            <h2>
                <img src="../IMGs/user.png">
            </h2>
            <form  method="POST">
                <p>Usuário:</p>
                <input type="text" name="usuariologin" placeholder="Login" maxlength="30" autofocus>
                <p>Senha:</p>
                <input type="password" name="senhalogin" placeholder="Senha" maxlength="20">
                <input type="submit" name="realizarlogin" value="Realizar Login">
                <a href="../PHP/cadastro.php" style="color: red;font-size: 18px;">Cadastrar-se</a>
                <p ></p>
                <a style="font-size: 15px;" href="#">Esqueceu a sua senha?</a>
            </form>
        </div>

<?php  
    
    if (isset($_POST["realizarlogin"])) {
    $usuario = $_POST["usuariologin"];
    $senha = $_POST["senhalogin"];
    $sql = "SELECT * FROM login";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
            $usu=$row['LOGIN_CLI'];
            $pwd=$row['SENHA_CLI'];
            } 
        if ($usuario == $usu && $senha == $pwd) {
            echo "<script>location.href='../PHP/conta.php';</script>";
            $_SESSION["logado"] = $_POST["usuariologin"];

            }else{ 
            echo "<h4 style='text-align: center;'>Senha ou Usuário incorretos</h4>";
            } 
    } 
   
$conn->close();
?>

        <!-- <?php  
         //if (isset($_POST["agendar"])) {
             //if ($_SESSION["logado"] != "") {
                 //$data = $_POST["data"];
                // $hora = $_POST["hora"];
                 //$desc = $_POST["desc"];

                 //$sql2 = "SELECT * FROM ordem_servico";
                 //$result = $conn->query($sql);

                // while ($row = $result->fetch_assoc()) {
                   // $databanco=$row['DATA'];
                    //$horabanco=$row['HORA'];
                // }

                //if ($data === $databanco || $hora === $horabanco) {
                    //echo "<h4 style='text-align: center;margin-top: -1%; font-size: 25px;'>A data agendada já esta em uso.</h4>";
                //}else{
                   // $sql = "INSERT INTO ordem_servico (DATA, HORA, DESC_ORD_SERV, COD_CLI) VALUES ('$data','$hora', '$desc', '$_SESSION[codigo]')";

                   // if ($conn->query($sql) === TRUE) {
                    //echo "<script>location.href='../PHP/conta.php';</script>";
                // }//
               // }              
         //}else{  
                //echo "<h4 style='text-align: center;margin-top: -1%; font-size: 25px;'>Realize o Login antes de agendar uma manutenção</h4>";
        // }
    // }
?> -->      
</body>
</html>