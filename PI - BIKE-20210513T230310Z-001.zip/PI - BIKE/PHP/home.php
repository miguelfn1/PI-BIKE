<?php session_start(); ?>
<!DOCTYPE html>
<html lang="">
<?php include '../PHP/head.php' ?>
<head>
    <title>Infinity Bikes - Home</title>
    <link rel="shortcurt icon" href="../IMGs/icon.png">
</head>
<style>
    body{
        font-family:Acme,sans-serif;
        font-size: 18px;
    }
    @media(max-width: 1050px) {
    body {
        background: none;
    }
</style>
<body>
    <?php
            echo "<div class='container'>
            <header>
                <input type='checkbox' id='btn-menu'>
                <label for='btn-menu'>&#9776;</label>
                <nav class='menu'>
                    <p id='logo_marca'><img src='../IMGs/logo-1.png' width='15%' alt=''>&nbsp;INFINITY BIKES</p>
                    <ul>
                        <li><a href='../PHP/home.php'>INICIO</a></li>
                        <li><a href='../PHP/servicos.php'>SERVIÇOS</a></li>
                        <li><a href='../PHP/sobre.php'>SOBRE NÓS</a></li>";
                        if ($_SESSION["logado"] != "") {
                                echo "<li><a href='../PHP/conta.php'>CONTA</a></li>
                                <li><a href='?lt'>SAIR</a></li>  ";
                            if (isset($_GET["lt"])) {
                               session_destroy();
                                echo "<script>location.href='../PHP/home.php';</script>";
                            }
                        }else{
                                echo "<li><a href='../PHP/login.php'>LOGIN</a></li>";
                        }
                     echo "
                    </ul>
                </nav>
            </header>
        </div>";

    ?>
    <div class="fundo_1">
        <div class="container">
            <div class="texto-index">
                <h3>Infinity Bikes</h3>
                <p>A bicicletaria que veio pra inovar e facilitar o mundo das bicicletas !</p><p>Faça seu agendamento !</p>
            </div>
        </div>
    </div>
    <div class="footer-desk">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="col-sm-4">
                            <h3 style="font-family: Acme;">Endereço</h3>
                            <p>R. Dr. Antônio Bento, 393 - Santo Amaro, São Paulo - SP, 04750-000
                            </p>
                            <h3 style="font-family: Acme;">Contato</h3>
                            <p><img src="../IMGs/whatsapp_icon.png" width="35"><strong>&nbsp;-&nbsp;<a href="https://api.whatsapp.com/send?1=pt_BR&phone=5511999119387">(11) - 99911-9387</a></strong></p>
                            <p><img src="../IMGs/email_icon.png" width="33"><strong>&nbsp;&nbsp;-&nbsp;<a href="mailto:infinitybikes@contato.com?subject=Questions" title="">E-mail Infinity Bikes</a></strong></p>
                        </div>
                        <div class="col-sm-4">
                            <h3 style="font-family: Acme;">Redes Sociais</h3>
                            <p><a href="https://www.facebook.com/Infinity-Bikes-105780014123761/?modal=admin_todo_tour" target="_blank"><img src="../IMGs/face_icon.png" width="40"></a>&nbsp;&nbsp;<a href="https://www.instagram.com/allsilva96/?hl=pt-br" target="_blank"><img src="../IMGs/instagram_icon.png" width="40"></a>&nbsp;&nbsp;<a href="#"><img src="../IMGs/twitter_icon.png" width="40"></a></p>
                        </div>
                        <div class="col-sm-4">
                            <p style="text-align: center;">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3654.806506333834!2d-46.70602948486924!3d-23.647099570649534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce50f8ac76dfdb%3A0xc160a87f059ec93d!2sSenac+Largo+Treze!5e0!3m2!1spt-BR!2sbr!4v1565979118195!5m2!1spt-BR!2sbr" width="300" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </p>
                        </div>
                        <br><br>
                        <div class="col-sm-12">
                            <p style="text-align: center;">&copy; Todos direitos reservados.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-mobile">

        </div>
        <br>
</body>
</html>
