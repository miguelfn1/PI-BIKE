<?php session_start(); ?>
<!DOCTYPE html>
<html lang="">
<?php include'head.php'?>
<head>
    <title>Infinity Bikes - Cadastro</title>
    <link rel="shortcurt icon" href="../IMGs/icon.png">
    <script src="../JS/mask.js"></script>
    
<style>
    @import url(http://fonts.googleapis.com/css?family=Roboto+Slab);
    body{
        font-family:Acme,sans-serif;
        font-size: 18px;
        padding: 0;
    }
    
    *{
        box-sizing:border-box;
        -webkit-box-sizing:border-box;
        -moz-box-sizing:border-box;
    }
    .container2{
        border: 1px solid gray;
        max-width: 600px;
        margin: auto;
        padding: 10px;
        font-size: 15px;
        font-weight: bold;
    }
    .header{
        background-color: #4180c5;
        text-align: center;
        max-width: 600px;
        color: aliceblue;
        padding: 10px;
        margin: auto;
        border: 1px solid gray;
        border-bottom: none;
    }
    .header h2{
        margin: 0;
        padding: 15px;
        width: 100%;  
    }
    form{
        margin-top: 15px;
    }
    input[type=text] {
        margin-bottom: 20px;
        margin-top: 10px;
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #7ac9b7;
        font-size: 18px;
    }
    input[type=password] {
        margin-bottom: 20px;
        margin-top: 10px;
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #7ac9b7;
        font-size: 18px;
    }
    input[type=radio] {
        margin-bottom: 20px;
        margin-top: 10px;
        font-size: 22px;
    }
    input[type=submit] {
        margin-bottom: 20px;
        width: 100%;
        padding: 15px;
        border-radius: 5px;
        border: 1px solid #7ac9b7;
        background: #4180c5;
        color: aliceblue;
        font-size: 18px;
        cursor: pointer;
        font-weight: bold;
    }

</style>
</head>
<body style="">
   <?php
            echo "<div class='container'>
            <header>
                <input type='checkbox' id='btn-menu'>
                <label for='btn-menu'>&#9776;</label>
                <nav class='menu'>
                    <p id='logo_marca'><img src='../IMGs/logo-1.png' width='15%' alt=''>&nbsp;INFINITY BIKES</p>
                    <ul>
                        <li><a href='../PHP/home.php'>INICIO</a></li>
                        <li><a href='../PHP/servicos.php'>SERVIÇOS</a></li>
                        <li><a href='../PHP/sobre.php'>SOBRE NÓS</a></li>";
                        if ($_SESSION["logado"] != "") {
                                echo "<li><a href='../PHP/conta.php'>CONTA</a></li>
                                <li><a href='?lt'>SAIR</a></li>  ";
                            if (isset($_GET["lt"])) {
                               session_destroy();
                                echo "<script>location.href='../PHP/home.php';</script>";
                            }
                        }else{
                                echo "<li><a href='../PHP/login.php'>LOGIN</a></li>";
                        }
                     echo "
                    </ul>
                </nav>
            </header>
        </div>";
    ?>

        <br>
        <div class="header">
            <h2>Cadastro</h2>
        </div>

        <div class="container" id="container2">
            <form method="POST">
                <label>Login:</label>
                <input type="text" name="login" placeholder="Login..." required maxlength="64" autofocus>
                <label>Senha:</label>
                <input type="password" name="senha" placeholder="Senha" required maxlength="64">
                <label>Confirmar Senha:</label>
                <input type="password" name="csenha" placeholder="Confirmar Senha" required maxlength="64">
                <label>Nome:</label>
                <input type="text" name="nome" placeholder="Nome" required maxlength="64">
                <label>CPF:</label>
                <input type="text" name="cpf" onkeydown="fMasc(this,mCPF)" placeholder="CPF" maxlength="14 ">
                <label>E-mail:</label> 
                <input type="text" name="email" placeholder="Exemplo@gmail.com.br" required maxlength="50">
                <label>Telefone:</label>
                <input type="text" name="telfixo" placeholder="Telefone Fixo" required maxlength="14" onkeydown="fMasc(this,mTel)">
                <label>Celular:</label>
                <input type="text" name="telcelular" placeholder="Celular" required maxlength="15" onkeydown="fMasc(this,mTel)">
                <label>Sexo:</label>
                <div class="form-inline">
                <label for="M">Masculino: </label>
                <input type="radio" name="sexo" id="M" value="masculino" required>&nbsp;&nbsp;&nbsp;  
                <label for="F">Feminino: </label>
                <input type="radio" name="sexo" id="F" value="feminino" required>&nbsp;&nbsp; 
                </div><br> 
                <label>Cidade:</label>
                <input type="text" name="cidade" placeholder="Cidade" required maxlength="50">
                <label>Estado:</label>
                <input type="text" name="estado" placeholder=".." required maxlength="2">
                <label>Logradouro:</label>
                <input type="text" name="logradouro" placeholder="..." required maxlength="100">
                <label>Número da Casa:</label>
                <input type="text" name="numcasa" placeholder="..." required maxlength="10">
                <label>Complemento:</label>
                <input type="text" name="complemento" placeholder="..." maxlength="30">
                <label>Bairro:</label>
                <input type="text" name="bairro" placeholder="..." required maxlength="50">
                <label>CEP:</label>
                <input type="text" name="cep" placeholder="..." required maxlength="10">
                <input type="submit" name="cadastro" value="Realizar Cadastro">
            </form>
        </div>

<?php

    if (isset($_POST["cadastro"])) {
            
            if ($_POST["senha"] === $_POST["csenha"]) {
            
            $login = $_POST["login"];
            $senha = $_POST["senha"];
            $nome = $_POST["nome"];
            $cpf = $_POST["cpf"];
            $email = $_POST["email"];
            $telfixo = $_POST["telfixo"];
            $telcelular = $_POST["telcelular"];
            $cidade = $_POST["cidade"];
            $estado = $_POST["estado"];
            $logradouro = $_POST["logradouro"];
            $numcasa = $_POST["numcasa"];
            $complemento = $_POST["complemento"];
            $bairro = $_POST["bairro"];
            $sexo = $_POST["sexo"];
            $cep = $_POST["cep"];


            $sql = "INSERT INTO login (LOGIN_CLI, SENHA_CLI) VALUES ('$login','$senha')";

            if ($conn->query($sql) === TRUE) {
                $COD_LOG = $conn->insert_id;

                $sql2 = "INSERT INTO clientes (COD_LOG, NOME_CLI, CPF_CLI, EMAIL_CLI, TEL_CLI_FIXO, TEL_CLI_CEL, SEXO_CLI)
                VALUES ('$COD_LOG', '$nome', '$cpf', '$email', '$telfixo', '$telcelular', '$sexo')";


                if ($conn->query($sql2) === TRUE) {
                    $COD_CLI = $conn->insert_id;
                    $sql3 = "INSERT INTO endereco_cliente (COD_CLI, LOGRA_END, COMP_CLI, CEP_CLI, NUM_END, BAIRRO_END, CID_END, EST_END) VALUES ('$COD_CLI', '$logradouro', '$complemento', '$cep', '$numcasa', '$bairro', '$cidade', '$estado')";
                    if ($conn->query($sql3) === TRUE) {
                        $_SESSION["codigo"] = $COD_CLI;
                        $_SESSION["logado"] = $_POST["login"];
                        echo "<script>location.href='../PHP/conta.php';</script>";
                    }else {
                        echo "Error: " . $sql3 . "<br>" . $conn->error;
                    } 
                }else {
                    $del = "DELETE FROM login where COD_LOG = $COD_LOG";
                    echo "Error: " . $sql2 . "<br>" . $conn->error;
                }
            }else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $conn->close();
        }else{
            echo "<h3 style='margin-left: 29%;'>As senhas devem ser iguais.</h3>";
        }
    }
?>

         <footer>
        <div class="container">
            <br><br>
            <p class="text-center">&copy; Todos direitos reservados.</p>
        </div>
    </footer>
</body>
</html>
