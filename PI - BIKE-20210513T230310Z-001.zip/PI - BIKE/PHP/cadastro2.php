<!DOCTYPE html>
<html>
<head>
  <?php include'head.php'?>
  <title>Infinity Bikes - Cadastro</title>
  <link rel="shortcurt icon" href="../IMGs/Icon_top.png">
  
  <style>
   body {
    margin: 0px;
    padding: 0px;
    background: url(../IMGs/road2.png)no-repeat;
    webkit-background-size:cover;
    background-size: cover;
    font-family:Acme,sans-serif;
    font-size: 16px;


  }
  
  @media(max-width: 1050px) {
    body {
      background: none;
      }}
      .form-area2{
        position: absolute;
        top:20%;
        left:40%;
        transform: translate(-50%, -50%);
        widows:400px;
        height:250px;
        box-sizing: border-box;
        background: rgba(0,0,0,0);
        padding:40px;
      }
      .form-area2 input[type=submit]{
        border: none;
        height: 40px;
        width: 17%;
        outline: none;
        color: #ffffff;
        font-size: 15px;
        background-color: #00bfff;
        cursor: pointer;
        border-radius: 10px;
        margin-left: 40%;

      }
    </style>
  </head>
  <body>

    <section class="container-fluid" style="width: 100%;">
      <section class="row justify-content-center">
        <section >
          <div class="form-area2">
            <form  method="POST">
              <div class="form-container">
                <div class="form-group">
                 <div class="col-lg-6 col-md-12 col-sm-12 ">
                  <label>Login:</label>
                  <input name="login" type="text" class="form-control" placeholder="Login..." required maxlength="50">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Senha:</label>
                  <input name="senha" type="password" class="form-control"  placeholder="Senha..." required maxlength="50">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Confirmar senha:</label>
                  <input name="csenha" type="password" class="form-control" placeholder="Confirmar senha..." required maxlength="50">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Nome:</label>
                  <input name="nome" type="text" class="form-control" placeholder="Nome..." required maxlength="100">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>CPF:</label>
                  <input name="cpf" type="text" class="form-control" onkeypress="$(this).mask('000.000.000-00')" placeholder="CPF..." required>
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>E-mail:</label>
                  <input name="email" type="text" class="form-control" placeholder="E-mail..." required maxlength="100">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Telefone Fixo:</label>
                  <input name="telfixo" type="text" class="form-control" onkeypress="$(this).mask('(00) 0000-0000')" placeholder="Telefone fixo..." required>
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Telefone Celular:</label>
                  <input name="telcelular" type="text" class="form-control" onkeypress="$(this).mask('(00) 00000-0000')" placeholder="Telefone celular..." required>
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Cidade:</label>
                  <input name="cidade" type="text" class="form-control" placeholder="Cidade..." required maxlength="50">
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Estado:</label>
                  <input name="estado" type="text" class="form-control" placeholder="Estado..." required maxlength="2">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Logradouro:</label>
                  <input name="logradouro" type="text" class="form-control" placeholder="Logradouro..." maxlength="100">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Numero da Casa:</label>
                  <input name="numcasa" type="text" class="form-control" placeholder="Número da casa..." required>
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Complemento:</label>
                  <input name="complemento" type="text" class="form-control" placeholder="Complemento..." required maxlength="100">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>Bairro:</label>
                  <input name="bairro" type="text" class="form-control" placeholder="Bairro..." required maxlength="100">
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group">
                  <label>CEP:</label>
                  <input name="cep" type="text" class="form-control" onkeypress="$(this).mask(' 00000-000')" placeholder="CEP..." required>
                </div>
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12 ">
                <div class="form-group form-check">
                  <label>Masculino: </label>
                  <input type="radio" name="sexo" value="masculino" class=" mr-3" required>  
                  <label>Feminino: </label>
                  <input type="radio" name="sexo" value="feminino" required> 
                </div>
              </div>
              
              
              <input style="width: 100%; border-radius: 10px; font-weight: bold;" type="submit" name="cadastro" value="Realizar Cadastro">
              
                
            </div>
          </section>
        </section>
      </section>


      

      
      

      

    </head>
    <body>

