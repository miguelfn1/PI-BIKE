<?php session_start(); ?>
<!DOCTYPE html>
<html lang="">
<?php include '../PHP/head.php' ?>
<head>
    <title>Infinity Bikes - Serviços</title>
    <link rel="shortcurt icon" href="../IMGs/icon.png">
    <script src="../JS/mask.js"></script>
<style>
    body{
        font-family:Acme,sans-serif;
        font-size: 18px;
        background-repeat: no-repeat;
        background-image: url(../IMGs/road2.png);     
    }
    .contact-form{
            width: 85%;
            max-width: 600px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 30px 40px;
            box-sizing: border-box;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 0 20px #000000b3;
        }
        .contact-form h1{
            margin-top: 0;
            font-weight: 200; 
        }
        .txtb{
            border-radius: 1px solid gray;  
            margin: 8px 0;
            padding: 12px 18px;
            border-radius: 8px;
        }
        .txtb label{
            display: block;
            text-align: left;
            color: #333;
            text-transform: uppercase;
            font-size: 15px;   
        }
        .txtb input, .txtb textarea{
            width: 100%;
            
            background: none;
            outline: none;
            font-size: 18px;
            margin-top: 6px;
        }
        input[type=submit]{
            display: block;
            background: #00bbf5;
            padding: 14px 0;
            color: white;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 8px;
            width: 100%;
        } 
</style>
</head>

<body style="">
   <?php
            echo "<div class='container'>
            <header>
                <input type='checkbox' id='btn-menu'>
                <label for='btn-menu'>&#9776;</label>
                <nav class='menu'>
                    <p id='logo_marca'><img src='../IMGs/logo-1.png' width='15%' alt=''>&nbsp;INFINITY BIKES</p>
                    <ul>
                        <li><a href='../PHP/home.php'>INICIO</a></li>
                        <li><a href='../PHP/servicos.php'>SERVIÇOS</a></li>
                        <li><a href='../PHP/sobre.php'>SOBRE NÓS</a></li>";
                        if ($_SESSION["logado"] != "") {
                                echo "<li><a href='../PHP/conta.php'>CONTA</a></li>
                                <li><a href='?lt'>SAIR</a></li>  ";
                            if (isset($_GET["lt"])) {
                               session_destroy();
                                echo "<script>location.href='../PHP/home.php';</script>";
                            }
                        }else{
                                echo "<li><a href='../PHP/login.php'>LOGIN</a></li>";
                        }
                     echo "
                    </ul>
                </nav>
            </header>
        </div>";
    ?>

    <form method="POST">   
    <div class="contact-form">
    <h1>Agendar Manutenção</h1>
    <div class="txtb">
        <label>Data:</label>
        <input type="text" name="data" placeholder="15/08/19" onkeydown="fMasc(this, mData)" required maxlength="8">
    </div>

    <div class="txtb">
        <label>Hora:</label>
        <input type="text" name="hora" placeholder="15:30" onkeydown="fMasc(this, mHora)" required maxlength="5">
    </div>

    <div class="txtb">
        <label>Descrição do Problema:</label>
        <textarea required maxlength="150" name="desc"></textarea>
    </div>
    <input type="submit" name="agendar" value="Enviar Agendamento">
    </div>
    </form>



<?php 

    if (isset($_POST["agendar"])) {
        if ($_SESSION["logado"] != "") {
            $data = $_POST["data"];
            $hora = $_POST["hora"];
            $desc = $_POST["desc"];
            $sql = "INSERT INTO ordem_servico (DATA, HORA, DESC_ORD_SERV, COD_CLI) VALUES ('$data','$hora', '$desc', '".$_SESSION['codigo']."')";
             
            if ($conn->query($sql) === TRUE) {
                echo "<script>location.href='../PHP/conta.php';</script>";
            }else{
                $conn->error;
            }
        }else{
            echo "<h4 style='text-align: center;margin-top: -1%; font-size: 25px;'>Realize o Login antes de agendar uma manutenção</h4>";
        }
    }

?>     

         <footer>
            <p style="margin-top: 43%;" class="text-center">&copy; Todos direitos reservados.</p>
        </footer>
</body>
</html>
