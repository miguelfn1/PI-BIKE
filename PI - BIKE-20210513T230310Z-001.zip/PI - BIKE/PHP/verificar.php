<!DOCTYPE html>
<html>
<head>
	<title>Infinity Bikes - Verificar</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/style.css">
    <link rel="shortcurt icon" href="../IMGs/Icon_top.png">
    <style>
    	body {
    margin: 0px;
    padding: 0px;
    background: url(../IMGs/road2.png)no-repeat;
    webkit-background-size:cover;
    background-size: cover;
    font-family:Acme,sans-serif;


}
    	.form-area{
        position: absolute;
        top:40%;
        left:50%;
        transform: translate(-50%, -50%);
        widows:400px;
        height:400px;
        box-sizing: border-box;
        background: rgba(0,0,0,0);
        padding:40px;
    }
    h2{
    	margin:0px;
    	padding: 0 0 20px;
    	font-weight: bold;
    	color: #ffffff;
    	text-align: center;
    }
    .form-area p{
    	margin: 0px;
    	padding: 0px;
    	font-weight: bold;
    	color: #00bfff;

    }
    .form-area input,select{
    	margin-bottom: 20px;
    	width: 100%;
    }
    .form-area input[type=text],
    .form-area input[type=email]
    {
    	border:none;
    	border-bottom: 1px solid #000000;
    	background-color:transparent;
    	outline:none;
    	height:40px;
    	color:#0000000;
    	display:16px;


    }
    .form-area input[type=password],
    .form-area input[ type=password]
    {
    	border: none;
    	border-bottom: 1px solid #000000;
    	background-color: transparent;
    	outline:none;
    	height: 40px;
    	color: #00bfff;
    	display: 16px;


    }
    ::placeholder{
    	color: #000000;
}
.form-area select 
{
	margin-top:20px;
	padding:10px 0;
}
.form-area input[type=submit]{
	border: none;
	height: 40px;
	outline: none;
	color: #ffffff;
	font-size: 15px;
	background-color: #00bfff;
	cursor: pointer;
	border-radius: 10px;
    font-weight: bold;

}

.form-area a {
	color: #00bfff;
	text-decoration: none;
	font-size: 14px;
	font-weight: bold;
}
@media(max-width: 1050px) {
    body {
        background: none;
    }
 
    	

    </style>
</head>
<body>
	<div class="container">
        <header>
            <input type="checkbox" id="btn-menu">
            <label for="btn-menu">&#9776;</label>
            <nav class="menu">
                <p id="logo_marca"><img src="../IMGs/logo-1.png" width="15%" alt="">&nbsp;INFINITY BIKES</p>
                <ul>
                    <li><a href="#" >INICIO</a></li>
                    <li><a href="#">SERVIÇOS</a></li>
                    <li><a href="#">SOBRE NÓS</a></li>
                    <li><a href="../PHP/login.php">LOGIN</a></li>
                </ul>
            </nav>
        </header>
    </div>
    <div class="container">
<?php 

session_start();
$_SESSION["usuario"] = $_POST["usuariologin"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "infinitybike";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

$usuario = $_POST["usuariologin"];
$senha = $_POST["senhalogin"];

$sql = "SELECT LOGIN_USU, SENHA_USU FROM usuarios where LOGIN_USU = '$usuario' and SENHA_USU = '$senha';";
    $result = $conn->query($sql);

if (isset($_POST["realizarlogin"])) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (($_POST["usuariologin"] === $row["LOGIN_USU"]) && ($_POST["senhalogin"] === $row["SENHA_USU"])) {
                echo "<form action='home.php' method='POST'>";
                echo "<h3 style='text-align:center;'>Login Efetuado com Sucesso!</h3><br>";
                echo "<input style='center;' type=submit name=next value='Acessar o site' class='btn btn-success'>";
                echo "</form>";
            }
        }
    }
    else{
        echo "<container>";
        echo "<form action='login.php' method='POST'><br><br>";
        echo "<h3 style='text-align:center;'>Usuário ou Senha incorreto, Tente Novamente ou realize o cadastro.<h3><br>";
        echo "<a  href='cadastro2.php'><h3 style='text-align:center;' >Não possui um cadastro?</h3></a><br><br>";
        echo "<input type=submit name=next value='Tentar Novamente' class='btn btn-success'>";
        echo "</form>";
        echo "</container>";
    }
}
$conn->close();
?>
</div>
    

		
     
</body>
</html>